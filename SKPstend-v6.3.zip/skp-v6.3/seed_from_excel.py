from pathlib import Path
from app.database import init_db
from app.services import publish_schedule

if __name__ == "__main__":
    init_db()
    source = Path("sample.xlsx")
    if not source.exists():
        raise SystemExit("Рядом должен лежать sample.xlsx")
    result = publish_schedule(source, original_filename=source.name)
    print(f"Опубликована версия {result['version']['version']}")
