from __future__ import annotations

import datetime as dt
import json
import shutil
from pathlib import Path
from typing import Any, Dict, List

from .config import (
    ARCHIVE_DIR,
    CURRENT_XLSX,
    PUBLISHED_SCHEDULE,
    PUBLISHED_VERSION,
)
from .database import get_conn
from .parser import parse_schedule_xlsx, write_schedule_json


def get_current_version_number() -> int:
    if not PUBLISHED_VERSION.exists():
        return 0
    try:
        data = json.loads(PUBLISHED_VERSION.read_text(encoding="utf-8"))
        return int(data.get("version", 0))
    except Exception:
        return 0


def get_current_version_info() -> Dict[str, Any]:
    if PUBLISHED_VERSION.exists():
        return json.loads(PUBLISHED_VERSION.read_text(encoding="utf-8"))
    return {
        "version": 0,
        "updated_at": None,
        "source_file": None,
        "items_count": 0,
        "groups_count": 0,
        "days_count": 0,
    }


def publish_schedule(xlsx_path: Path, original_filename: str | None = None) -> Dict[str, Any]:
    payload = parse_schedule_xlsx(xlsx_path)
    next_version = get_current_version_number() + 1

    archive_name = f"v{next_version:04d}_{xlsx_path.name}"
    archive_target = ARCHIVE_DIR / archive_name
    shutil.copy2(xlsx_path, archive_target)
    shutil.copy2(xlsx_path, CURRENT_XLSX)

    write_schedule_json(payload, PUBLISHED_SCHEDULE)

    version_info = {
        "version": next_version,
        "updated_at": dt.datetime.now().isoformat(timespec="seconds"),
        "source_file": original_filename or xlsx_path.name,
        "items_count": len(payload["items"]),
        "groups_count": len(payload["groups"]),
        "days_count": len(payload["days"]),
    }
    PUBLISHED_VERSION.write_text(json.dumps(version_info, ensure_ascii=False, indent=2), encoding="utf-8")

    with get_conn() as conn:
        conn.execute(
            """
            INSERT INTO uploads (
                created_at, filename, archived_path, status, version, message,
                items_count, groups_count, days_count
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                version_info["updated_at"],
                original_filename or xlsx_path.name,
                str(archive_target.relative_to(archive_target.parent.parent)),
                "published",
                next_version,
                "Публикация успешна",
                version_info["items_count"],
                version_info["groups_count"],
                version_info["days_count"],
            ),
        )
        conn.commit()

    return {"version": version_info, "schedule": payload, "validation": payload.get("validation", {}), "diagnostics": payload.get("diagnostics", {}), "parser_info": payload.get("parser_info", {})}


def rollback_to_version(version: int) -> Dict[str, Any]:
    matches = sorted(ARCHIVE_DIR.glob(f"v{version:04d}_*.xlsx"))
    if not matches:
        raise FileNotFoundError(f"Архив для версии {version} не найден")
    source = matches[0]
    return publish_schedule(source, original_filename=source.name)


def load_schedule() -> Dict[str, Any]:
    if not PUBLISHED_SCHEDULE.exists():
        return {
            "source_file": None,
            "sheet": None,
            "generated_at": None,
            "groups": [],
            "days": [],
            "items": [],
        }
    return json.loads(PUBLISHED_SCHEDULE.read_text(encoding="utf-8"))


def history(limit: int = 50) -> List[Dict[str, Any]]:
    with get_conn() as conn:
        rows = conn.execute(
            "SELECT created_at, filename, archived_path, status, version, message, items_count, groups_count, days_count "
            "FROM uploads ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
    return [dict(row) for row in rows]
