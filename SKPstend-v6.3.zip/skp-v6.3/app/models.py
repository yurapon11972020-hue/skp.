from __future__ import annotations

from pydantic import BaseModel, Field
from typing import Optional, List


class ScheduleItem(BaseModel):
    date: str
    weekday: str
    pair: int
    time: str
    group: str
    subject: str
    teacher: Optional[str] = None
    room: Optional[str] = None


class DayInfo(BaseModel):
    date: str
    weekday: str


class SchedulePayload(BaseModel):
    source_file: str
    sheet: str
    generated_at: str
    groups: List[str] = Field(default_factory=list)
    days: List[DayInfo] = Field(default_factory=list)
    items: List[ScheduleItem] = Field(default_factory=list)


class VersionInfo(BaseModel):
    version: int
    updated_at: str
    source_file: str
    items_count: int
    groups_count: int
    days_count: int
