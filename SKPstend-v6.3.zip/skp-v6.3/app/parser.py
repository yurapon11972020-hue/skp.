from __future__ import annotations

import datetime as dt
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Tuple

import openpyxl

WEEKDAYS = {
    "ПОНЕДЕЛЬНИК",
    "ВТОРНИК",
    "СРЕДА",
    "ЧЕТВЕРГ",
    "ПЯТНИЦА",
    "СУББОТА",
    "ВОСКРЕСЕНЬЕ",
}
GROUP_RE = re.compile(r"^[A-Za-zА-Яа-яЁё0-9]+(?:[A-Za-zА-Яа-яЁё0-9\-/]+)*(?:\([^\)]+\))?$")
DATE_RE = re.compile(r"(\d{2}\.\d{2}\.\d{4})")
TIME_RE = re.compile(r"\b\d{1,2}[:.]\d{2}\s*[-–]\s*\d{1,2}[:.]\d{2}\b")
TEACHER_RE = re.compile(r"\b[А-ЯЁ][а-яё-]{2,}\s+[А-ЯЁ]\.\s*[А-ЯЁ]\.?")
PAREN_ONLY_RE = re.compile(r"^\([^)]{1,8}\)$")
ROOM_RE = re.compile(r"^(?:каб\.?\s*)?[A-Za-zА-Яа-яЁё0-9\-/]{1,12}$")
HEADER_WORDS = {"№", "ГРУППА:", "ДЕНЬ НЕДЕЛИ", "ЗАНЯТИЕ", "ВРЕМЯ", "ДИСЦИПЛИНА", "ПРЕПОДАВАТЕЛЬ", "АУД.", "АУД", "ПРЕПОДАВАТЕЛИ"}
PRACTICE_HIDE_ROOM_MARKERS = ("ПРАКТИКА", "УЧЕБНАЯ ПРАКТИКА", "ПРОИЗВОДСТВЕННАЯ ПРАКТИКА")
PRODUCTION_PRACTICE_MARKERS = ("ПРОИЗВОДСТВЕННАЯ ПРАКТИКА",)
SPORT_SUBJECT_MARKERS = ("ФИЗИЧЕСКАЯ КУЛЬТУРА", "ФИЗКУЛЬТУРА", "ФИЗ. КУЛЬТУРА", "ФИЗКУЛЬТ")
SPORT_LOCATION_KEYWORDS = ("КСК", "ШКОЛА", "СНЕЖИНК", "ГЕОЛОГ", "ДОСААФ", "СПОРТ", "ЗАЛ", "СТАДИОН",)
SPORT_LOCATION_NORMALIZATIONS = (
    (("КСК", "ГЕОЛОГ"), "КСК Геолог"),
    (("32-Я", "ШКОЛ"), "32-я школа"),
    (("СНЕЖИНК",), "Снежинка"),
    (("ДОСААФ",), "ДОСААФ"),
    (("СПОРТИВНЫЙ", "ЗАЛ"), "Спортивный зал"),
    (("ТРЕНАЖ", "ЗАЛ"), "Тренажёрный зал"),
)
FORMAT_NORMALIZATIONS = (
    (("ВИДЕО", "ЛЕК"), "Видеолекция"),
    (("ВИДЕОЛЕК",), "Видеолекция"),
    (("ДИСТАНТ",), "Дистант"),
    (("ОНЛАЙН",), "Дистант"),
    (("ВИДЕО",), "Дистант"),
)
LOCATION_KEYWORDS = ("АРХИВ", "МУЗЕЙ", "БИБЛИОТЕК", "ТЕАТР", "ЦЕНТР", "КОМПЛЕКС", "ПАРК", "ВЫСТАВ", "МЕЛИК", "УЛ.", "УЛИЦ", "ПР-Т", "ПРОСП", "АДРЕС")
ADDRESS_RE = re.compile(r"\b(?:ул\.?|улица|пр-т|проспект|д\.?|дом)\b", re.IGNORECASE)


class ScheduleParseError(ValueError):
    pass


@dataclass
class GroupBlock:
    name: str
    start_col: int
    end_col: int


@dataclass
class Candidate:
    text: str
    row: int
    col: int


class Grid:
    def __init__(self, ws: openpyxl.worksheet.worksheet.Worksheet):
        self.ws = ws
        self.merged_map: Dict[Tuple[int, int], Any] = {}
        for mr in ws.merged_cells.ranges:
            min_col, min_row, max_col, max_row = mr.bounds
            top_val = ws.cell(min_row, min_col).value
            for r in range(min_row, max_row + 1):
                for c in range(min_col, max_col + 1):
                    self.merged_map[(r, c)] = top_val

    def value(self, r: int, c: int) -> Any:
        value = self.ws.cell(r, c).value
        if value is None:
            value = self.merged_map.get((r, c))
        return normalize_text(value)


def normalize_text(value: Any) -> Any:
    if isinstance(value, str):
        value = value.replace("\xa0", " ").replace("\r", "\n")
        value = re.sub(r"[ \t]+", " ", value)
        value = re.sub(r"\n{3,}", "\n\n", value)
        value = value.strip()
        if not value:
            return None
    return value


def looks_like_group(text: Any) -> bool:
    if not isinstance(text, str):
        return False
    t = text.strip().upper()
    if not t or t in HEADER_WORDS:
        return False
    if DATE_RE.search(t) or TIME_RE.search(t) or t in WEEKDAYS:
        return False
    if not re.search(r"\d", t):
        return False
    return bool(GROUP_RE.match(t))


def detect_header_row(grid: Grid, max_scan_rows: int = 20) -> int:
    best_row = 0
    best_score = -1
    for r in range(1, min(max_scan_rows, grid.ws.max_row) + 1):
        score = sum(1 for c in range(1, grid.ws.max_column + 1) if looks_like_group(grid.value(r, c)))
        if score > best_score:
            best_score = score
            best_row = r
    if best_score < 3:
        raise ScheduleParseError("Не удалось распознать строку заголовков с группами. Проверь шапку Excel.")
    return best_row


def detect_core_columns(grid: Grid, header_row: int) -> Tuple[int, int]:
    pair_col = None
    time_col = None
    for r in range(max(1, header_row - 3), header_row + 1):
        for c in range(1, min(12, grid.ws.max_column) + 1):
            value = grid.value(r, c)
            if isinstance(value, str):
                upper = value.upper().strip()
                if upper == "№":
                    pair_col = c
                elif upper == "ВРЕМЯ":
                    time_col = c
    if pair_col is None:
        for c in range(1, min(8, grid.ws.max_column) + 1):
            vals = [grid.value(r, c) for r in range(header_row + 1, min(grid.ws.max_row, header_row + 20) + 1)]
            if sum(1 for v in vals if isinstance(v, int) and 1 <= v <= 8) >= 3:
                pair_col = c
                break
    if time_col is None:
        for c in range(1, min(10, grid.ws.max_column) + 1):
            vals = [grid.value(r, c) for r in range(header_row + 1, min(grid.ws.max_row, header_row + 20) + 1)]
            if sum(1 for v in vals if isinstance(v, str) and TIME_RE.search(v)) >= 3:
                time_col = c
                break
    if pair_col is None or time_col is None:
        raise ScheduleParseError("Не удалось найти служебные колонки номера пары и времени.")
    return pair_col, time_col


def detect_group_blocks(grid: Grid, header_row: int) -> List[GroupBlock]:
    starts: List[Tuple[int, str]] = []
    for c in range(1, grid.ws.max_column + 1):
        value = grid.value(header_row, c)
        if not looks_like_group(value):
            continue
        name = str(value).strip()
        left = grid.value(header_row, c - 1) if c > 1 else None
        left_name = str(left).strip() if isinstance(left, str) else left
        if left_name == name:
            continue
        starts.append((c, name))
    if not starts:
        raise ScheduleParseError("Не удалось распознать ни одной группы в строке заголовков.")
    blocks: List[GroupBlock] = []
    for i, (start, name) in enumerate(starts):
        next_start = starts[i + 1][0] if i + 1 < len(starts) else grid.ws.max_column + 1
        blocks.append(GroupBlock(name=name, start_col=start, end_col=max(start, next_start - 1)))
    return blocks


def parse_date_weekday(text: Any) -> Tuple[str | None, str | None]:
    if isinstance(text, (dt.date, dt.datetime)):
        return text.strftime("%d.%m.%Y"), None
    if not isinstance(text, str):
        return None, None
    match = DATE_RE.search(text)
    if not match:
        return None, None
    date_text = match.group(1)
    upper = text.upper()
    weekday = next((w.capitalize() for w in WEEKDAYS if w in upper), None)
    return date_text, weekday


def detect_day_context(grid: Grid, row: int) -> Tuple[str | None, str | None]:
    for c in range(1, min(6, grid.ws.max_column) + 1):
        date_text, weekday = parse_date_weekday(grid.value(row, c))
        if date_text:
            if not weekday:
                for c2 in range(1, min(6, grid.ws.max_column) + 1):
                    v = grid.value(row, c2)
                    if isinstance(v, str) and v.strip().upper() in WEEKDAYS:
                        weekday = v.strip().capitalize()
                        break
            return date_text, weekday
    return None, None


def detect_pair_rows(grid: Grid, header_row: int, pair_col: int, time_col: int) -> List[int]:
    rows = []
    for r in range(header_row + 1, grid.ws.max_row + 1):
        pair_value = grid.value(r, pair_col)
        time_value = grid.value(r, time_col)
        if isinstance(pair_value, int) and 1 <= pair_value <= 8 and isinstance(time_value, str) and TIME_RE.search(time_value):
            rows.append(r)
    if not rows:
        raise ScheduleParseError("Файл прочитан, но строки с парами не найдены. Проверь номера пар, время и объединённые ячейки.")
    return rows


def clean_candidate(text: str) -> str:
    text = normalize_text(text)
    if not isinstance(text, str):
        return ""
    return text.strip(" -–;,")


def split_multiline_values(values: Iterable[str]) -> List[str]:
    items: List[str] = []
    for value in values:
        for part in re.split(r"\n+", value):
            part = clean_candidate(part)
            if part:
                items.append(part)
    return items


def classify_format_value(text: str) -> str | None:
    upper = text.upper()
    for markers, normalized in FORMAT_NORMALIZATIONS:
        if all(marker in upper for marker in markers):
            return normalized
    return None


def looks_like_location_value(text: str) -> bool:
    upper = text.upper()
    if TEACHER_RE.fullmatch(text):
        return False
    if any(key in upper for key in LOCATION_KEYWORDS):
        return True
    if ADDRESS_RE.search(text):
        return True
    return False


def has_any_marker(text: str | None, markers: tuple[str, ...]) -> bool:
    if not text:
        return False
    upper = text.upper()
    return any(marker in upper for marker in markers)


def is_production_practice(text: str | None) -> bool:
    return has_any_marker(text, PRODUCTION_PRACTICE_MARKERS)


def should_hide_room_for_practice(text: str | None) -> bool:
    return has_any_marker(text, PRACTICE_HIDE_ROOM_MARKERS)


def is_sport_subject(text: str | None) -> bool:
    return has_any_marker(text, SPORT_SUBJECT_MARKERS)


def normalize_time_range(text: str) -> str:
    text = text.replace('–', '-').replace('—', '-').replace('.', ':')
    text = re.sub(r'\s+', '', text)
    return text


def extract_time_from_text(text: str | None) -> str | None:
    if not text:
        return None
    match = TIME_RE.search(text)
    if not match:
        return None
    return normalize_time_range(match.group(0))


def remove_time_from_text(text: str | None) -> str | None:
    if not text:
        return text
    cleaned = TIME_RE.sub(' ', text)
    cleaned = clean_candidate(cleaned)
    return cleaned or None


def normalize_sport_location(text: str) -> str:
    upper = text.upper()
    for markers, normalized in SPORT_LOCATION_NORMALIZATIONS:
        if all(marker in upper for marker in markers):
            return normalized
    return text


def combine_sport_locations(locations: List[str]) -> List[str]:
    normalized = [normalize_sport_location(x) for x in locations if x]
    upper_joined = " ".join(x.upper() for x in normalized)
    combined = []
    for markers, name in SPORT_LOCATION_NORMALIZATIONS:
        if all(marker in upper_joined for marker in markers) and name not in combined:
            combined.append(name)
    for loc in normalized:
        if loc not in combined:
            combined.append(loc)
    return combined


def is_room_candidate(text: str) -> bool:
    upper = text.upper()
    if "КАБ" in upper or "АУД" in upper:
        return True
    return bool(ROOM_RE.match(text) and len(text) <= 12 and re.search(r"\d", text))


def normalize_room(text: str) -> str:
    return clean_candidate(re.sub(r"^(?:каб\.?|ауд\.?)\s*", "", text, flags=re.IGNORECASE))


def looks_like_short_broken_subject(text: str | None) -> bool:
    if not text:
        return True
    cleaned = re.sub(r"\([^)]*\)", "", text).strip()
    if PAREN_ONLY_RE.fullmatch(text.strip()):
        return True
    return len(cleaned) < 4


def extract_candidates(grid: Grid, block: GroupBlock, row_start: int, row_end: int) -> List[Candidate]:
    values: List[Candidate] = []
    for r in range(row_start, row_end + 1):
        for c in range(block.start_col, block.end_col + 1):
            value = grid.value(r, c)
            if isinstance(value, str):
                values.append(Candidate(text=value, row=r, col=c))
            elif isinstance(value, (int, float)) and c == block.end_col:
                rendered = str(int(value) if float(value).is_integer() else value)
                values.append(Candidate(text=rendered, row=r, col=c))
    dedup = []
    seen = set()
    for item in values:
        key = (item.text.strip(), item.row)
        if item.text.strip() and key not in seen:
            seen.add(key)
            dedup.append(item)
    return dedup


def pick_subject_teacher_room(candidates: List[Candidate], group_name: str, aud_col: int) -> Tuple[str | None, str | None, str | None, str | None, str | None]:
    teacher = None
    room = None
    room_label = None
    subject_time = None
    sport_locations: List[str] = []
    embedded_locations: List[str] = []
    aud_places: List[Tuple[str, str]] = []
    raw_parts: List[str] = []

    for cand in candidates:
        text = clean_candidate(cand.text)
        if not text:
            continue
        upper = text.upper()
        if upper in HEADER_WORDS or upper == group_name.upper() or upper in WEEKDAYS:
            continue
        if DATE_RE.search(text):
            continue

        if cand.col == aud_col:
            fmt = classify_format_value(text)
            if fmt:
                aud_places.append(("Формат", fmt))
                continue
            if is_room_candidate(text):
                aud_places.append(("Аудитория", normalize_room(text)))
                continue
            if any(keyword in upper for keyword in SPORT_LOCATION_KEYWORDS):
                aud_places.append(("Расположение", normalize_sport_location(text)))
                continue
            if looks_like_location_value(text):
                aud_places.append(("Место проведения", text))
                continue

        raw_parts.append(text)

    subject_parts: List[str] = []
    for text in split_multiline_values(raw_parts):
        inline_time = extract_time_from_text(text)
        if inline_time and subject_time is None:
            subject_time = inline_time
        text = remove_time_from_text(text)
        if not text:
            continue

        upper = text.upper()
        fmt = classify_format_value(text)
        if fmt:
            if not any(label == "Формат" for label, _ in aud_places):
                aud_places.append(("Формат", fmt))
            continue

        if any(keyword in upper for keyword in SPORT_LOCATION_KEYWORDS):
            sport_locations.append(normalize_sport_location(text))
            continue

        if TEACHER_RE.fullmatch(text):
            if teacher is None:
                teacher = text if text.endswith('.') else text + '.'
            continue

        if looks_like_location_value(text) and not is_sport_subject(text):
            embedded_locations.append(text)
            continue

        if is_room_candidate(text):
            if room is None:
                room = normalize_room(text)
                room_label = "Аудитория"
            continue

        teacher_match = TEACHER_RE.search(text)
        if teacher_match and teacher is None:
            teacher = teacher_match.group(0)
            if not teacher.endswith('.'):
                teacher += '.'
            text = clean_candidate(text.replace(teacher, " "))
            if not text:
                continue

        room_match = re.search(r"(?:\b(?:каб\.?|ауд\.?)\s*\S+|\b\d{1,3}[A-Za-zА-Яа-яЁё/-]?)$", text, flags=re.IGNORECASE)
        if room_match:
            candidate_room = normalize_room(room_match.group(0))
            before = clean_candidate(text[:room_match.start()])
            if before and not looks_like_short_broken_subject(before):
                if room is None:
                    room = candidate_room
                    room_label = "Аудитория"
                text = before

        if text:
            subject_parts.append(text)

    subject = None
    if subject_parts:
        ranked = sorted(subject_parts, key=lambda s: (looks_like_short_broken_subject(s), -len(s)))
        subject = ranked[0]
        if looks_like_short_broken_subject(subject):
            merged = clean_candidate(" ".join(subject_parts))
            if merged and not looks_like_short_broken_subject(merged):
                subject = merged
    else:
        merged = clean_candidate(" ".join(remove_time_from_text(x) or '' for x in raw_parts))
        if merged:
            subject = merged

    if subject:
        candidate_time = extract_time_from_text(subject)
        if candidate_time and subject_time is None:
            subject_time = candidate_time
        subject = remove_time_from_text(subject)

    if looks_like_short_broken_subject(subject):
        merged = clean_candidate(" ".join(
            clean_candidate((remove_time_from_text(x) or '').replace(teacher or '', ' '))
            for x in raw_parts
            if not TEACHER_RE.fullmatch(clean_candidate(remove_time_from_text(x) or '')) and not is_room_candidate(clean_candidate(remove_time_from_text(x) or ''))
        ))
        if merged and not looks_like_short_broken_subject(merged):
            subject = merged

    if teacher and not TEACHER_RE.fullmatch(teacher):
        subject = clean_candidate(f"{subject or ''} {teacher}")
        teacher = None

    if is_sport_subject(subject):
        explicit = next((value for label, value in aud_places if label == "Расположение"), None)
        if explicit:
            room = explicit
            room_label = "Расположение"
        elif sport_locations:
            for location in combine_sport_locations(sport_locations):
                if not TEACHER_RE.search(location) and location.upper() != (subject or "").upper():
                    room = location
                    room_label = "Расположение"
                    break
    else:
        # Для обычных предметов колонка Ауд. может содержать не только кабинет,
        # но и внешнюю локацию вроде ДОСААФ/Городской архив. Если в узкой колонке
        # нашли спорт-локацию, но сам предмет не физкультура, показываем это как
        # обычное место проведения, а не теряем и не падаем в Актовый зал.
        for preferred_label in ("Формат", "Место проведения", "Аудитория", "Расположение"):
            explicit = next((value for label, value in aud_places if label == preferred_label), None)
            if explicit:
                room = explicit
                room_label = "Место проведения" if preferred_label == "Расположение" else preferred_label
                break
        if not room and sport_locations:
            combined_locations = combine_sport_locations(sport_locations)
            if combined_locations:
                room = combined_locations[0]
                room_label = "Место проведения"
        if not room and embedded_locations:
            room = embedded_locations[0]
            room_label = "Место проведения"

    if is_production_practice(subject):
        teacher = None
        room = None
        room_label = None
    elif should_hide_room_for_practice(subject):
        room = None
        room_label = None
    elif subject and not room:
        room = 'Актовый зал'
        room_label = 'Аудитория'

    return subject or None, teacher or None, room or None, room_label or None, subject_time or None


def apply_business_rules(records: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    sport_days = {(item["group"], item["date"]) for item in records if is_sport_subject(item.get("subject"))}
    for item in records:
        subject = item.get("subject")
        if is_sport_subject(subject):
            if item.get("room") and not item.get("room_label"):
                item["room_label"] = "Расположение"
        elif (item.get("group"), item.get("date")) in sport_days and not should_hide_room_for_practice(subject):
            item["room"] = "Дистант"
            item["room_label"] = "Формат"
    return records


def extract_sport_location_from_zone(grid: Grid, block: GroupBlock, row_start: int, row_end: int) -> str | None:
    locations: List[str] = []
    col_start = max(1, block.start_col - 1)
    col_end = min(grid.ws.max_column, block.end_col + 2)
    row_limit = min(grid.ws.max_row, row_end + 1)
    for r in range(row_start, row_limit + 1):
        for c in range(col_start, col_end + 1):
            value = grid.value(r, c)
            if not isinstance(value, str):
                continue
            for part in split_multiline_values([value]):
                upper = part.upper()
                if any(keyword in upper for keyword in SPORT_LOCATION_KEYWORDS):
                    locations.append(normalize_sport_location(part))
    combined = combine_sport_locations(locations)

    def rank(loc: str) -> tuple[int, int]:
        upper = loc.upper()
        generic = 1 if upper in {"СПОРТИВНЫЙ ЗАЛ", "ТРЕНАЖЁРНЫЙ ЗАЛ", "ТРЕНАЖЕРНЫЙ ЗАЛ", "ЗАЛ"} else 0
        return (generic, len(loc))

    filtered = [loc for loc in combined if not TEACHER_RE.search(loc)]
    if not filtered:
        return None
    filtered.sort(key=rank)
    return filtered[0]


def validate_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
    items = payload.get("items", [])
    groups = payload.get("groups", [])
    days = payload.get("days", [])
    problems: List[str] = []
    warnings: List[str] = []
    if not items:
        problems.append("Не найдено ни одной пары после парсинга.")
    if len(groups) < 2:
        problems.append("Распознано слишком мало групп.")
    if not days:
        problems.append("Не распознаны даты расписания.")
    today = dt.date.today()
    recent_days = 0
    for d in days:
        try:
            parsed = dt.datetime.strptime(d["date"], "%d.%m.%Y").date()
            if parsed >= today - dt.timedelta(days=7):
                recent_days += 1
        except Exception:
            warnings.append(f"Не удалось проверить дату {d['date']}")
    if days and recent_days == 0:
        warnings.append("В файле нет ближайших дат; возможно, загружена старая неделя.")
    empty_groups = [g for g in groups if g not in {item["group"] for item in items}]
    if empty_groups:
        warnings.append(f"Без пар распознано групп: {len(empty_groups)}")
    suspicious = [
        item for item in items
        if looks_like_short_broken_subject(item.get("subject")) or (item.get("teacher") and not TEACHER_RE.fullmatch(item.get("teacher")))
    ]
    if suspicious:
        warnings.append(f"Подозрительных записей: {len(suspicious)}")
    return {"status": "ok" if not problems else "error", "problems": problems, "warnings": warnings, "suspicious_count": len(suspicious)}


def parse_schedule_xlsx(source: Path) -> Dict[str, Any]:
    wb = openpyxl.load_workbook(source, data_only=True)
    sheet_diagnostics = []
    best_payload = None
    best_score = -1

    for ws in [wb[name] for name in wb.sheetnames]:
        grid = Grid(ws)
        try:
            header_row = detect_header_row(grid)
            pair_col, time_col = detect_core_columns(grid, header_row)
            blocks = detect_group_blocks(grid, header_row)
            pair_rows = detect_pair_rows(grid, header_row, pair_col, time_col)

            current_date = None
            current_weekday = None
            records: List[Dict[str, Any]] = []
            for idx, row in enumerate(pair_rows):
                maybe_date, maybe_weekday = detect_day_context(grid, row)
                if maybe_date:
                    current_date = maybe_date
                    current_weekday = maybe_weekday or current_weekday
                if not current_date:
                    for back in range(max(header_row + 1, row - 2), row + 1):
                        maybe_date, maybe_weekday = detect_day_context(grid, back)
                        if maybe_date:
                            current_date = maybe_date
                            current_weekday = maybe_weekday or current_weekday
                            break
                if not current_date:
                    continue

                row_end = pair_rows[idx + 1] - 1 if idx + 1 < len(pair_rows) else ws.max_row
                pair_number = int(grid.value(row, pair_col))
                time_range = str(grid.value(row, time_col))
                for block in blocks:
                    candidates = extract_candidates(grid, block, row, row_end)
                    subject, teacher, room, room_label, subject_time = pick_subject_teacher_room(candidates, block.name, block.end_col)
                    if subject and is_sport_subject(subject):
                        zone_location = extract_sport_location_from_zone(grid, block, row, row_end)
                        if zone_location:
                            room = zone_location
                            room_label = "Расположение"
                    if subject:
                        records.append({
                            "date": current_date,
                            "weekday": (current_weekday or "").capitalize() if current_weekday else "",
                            "pair": pair_number,
                            "time": subject_time or time_range,
                            "group": block.name,
                            "subject": subject,
                            "teacher": teacher,
                            "room": room,
                            "room_label": room_label,
                        })

            dedup_records = []
            seen_keys = set()
            for item in records:
                key = (item["date"], item["pair"], item["time"], item["group"], item["subject"], item.get("teacher"), item.get("room"), item.get("room_label"))
                if key not in seen_keys:
                    seen_keys.add(key)
                    dedup_records.append(item)

            dedup_records = apply_business_rules(dedup_records)

            seen_days = set()
            days = []
            for item in dedup_records:
                key = (item["date"], item["weekday"])
                if key not in seen_days:
                    seen_days.add(key)
                    days.append({"date": item["date"], "weekday": item["weekday"]})

            payload = {
                "source_file": source.name,
                "sheet": ws.title,
                "generated_at": dt.datetime.now().isoformat(timespec="seconds"),
                "groups": [b.name for b in blocks],
                "days": days,
                "items": dedup_records,
                "parser_info": {
                    "mode": "layout-semantic-v6.4.1-teacher-fix",
                    "header_row": header_row,
                    "pair_col": pair_col,
                    "time_col": time_col,
                    "group_blocks": len(blocks),
                    "pair_rows": len(pair_rows),
                },
            }
            validation = validate_payload(payload)
            payload["validation"] = validation
            score = len(dedup_records)
            sheet_diagnostics.append({"sheet": ws.title, "status": validation["status"], "items": len(dedup_records), "groups": len(blocks), "days": len(days)})
            if score > best_score:
                best_score = score
                best_payload = payload
        except Exception as exc:
            sheet_diagnostics.append({"sheet": ws.title, "status": "error", "message": str(exc)})

    if not best_payload:
        details = "; ".join(f"{x['sheet']}: {x.get('message', 'ошибка')}" for x in sheet_diagnostics) or "парсер не смог разобрать листы"
        raise ScheduleParseError(f"Не удалось разобрать Excel. Диагностика: {details}")

    if best_payload["validation"]["status"] != "ok":
        problems = "; ".join(best_payload["validation"]["problems"])
        raise ScheduleParseError(f"Файл разобран частично, но валидация не пройдена: {problems}")

    best_payload["diagnostics"] = {"sheets": sheet_diagnostics}
    return best_payload


def write_schedule_json(payload: Dict[str, Any], target: Path) -> None:
    tmp = target.with_suffix(target.suffix + ".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(target)
