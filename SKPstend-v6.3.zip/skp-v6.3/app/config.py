from __future__ import annotations

import os
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
UPLOADS_DIR = DATA_DIR / "uploads"
ARCHIVE_DIR = DATA_DIR / "archive"
PUBLISHED_DIR = DATA_DIR / "published"
LOGS_DIR = DATA_DIR / "logs"
DB_PATH = DATA_DIR / "app.db"
PUBLISHED_SCHEDULE = PUBLISHED_DIR / "schedule.json"
PUBLISHED_VERSION = PUBLISHED_DIR / "version.json"
CURRENT_XLSX = UPLOADS_DIR / "current_schedule.xlsx"
TEMP_XLSX = UPLOADS_DIR / "incoming.xlsx"

for path in [DATA_DIR, UPLOADS_DIR, ARCHIVE_DIR, PUBLISHED_DIR, LOGS_DIR]:
    path.mkdir(parents=True, exist_ok=True)

ADMIN_USERNAME = os.getenv("ADMIN_USERNAME", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "admin123")
SECRET_KEY = os.getenv("SECRET_KEY", "change-this-secret-key-for-production")
SESSION_COOKIE_NAME = "skp_admin_session"
SESSION_TTL_SECONDS = int(os.getenv("SESSION_TTL_SECONDS", "43200"))  # 12 hours
