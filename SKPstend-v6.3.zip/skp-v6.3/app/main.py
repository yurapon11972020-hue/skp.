from __future__ import annotations

import hashlib
import hmac
import shutil
import time
from pathlib import Path
from urllib.parse import quote

from fastapi import Depends, FastAPI, File, Form, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles

from .config import (
    ADMIN_PASSWORD,
    ADMIN_USERNAME,
    BASE_DIR,
    SECRET_KEY,
    SESSION_COOKIE_NAME,
    SESSION_TTL_SECONDS,
    TEMP_XLSX,
)
from .database import init_db
from .services import (
    get_current_version_info,
    history,
    load_schedule,
    publish_schedule,
    rollback_to_version,
)

app = FastAPI(title="Stend Schedule MVP", version="1.1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

static_dir = BASE_DIR / "static"
app.mount("/static", StaticFiles(directory=static_dir), name="static")


def _sign_value(value: str) -> str:
    return hmac.new(SECRET_KEY.encode("utf-8"), value.encode("utf-8"), hashlib.sha256).hexdigest()


def create_session_cookie(username: str) -> str:
    expires = int(time.time()) + SESSION_TTL_SECONDS
    payload = f"{username}|{expires}"
    return f"{payload}|{_sign_value(payload)}"


def parse_session_cookie(cookie_value: str | None) -> str | None:
    if not cookie_value:
        return None
    try:
        username, expires_str, signature = cookie_value.split("|", 2)
        payload = f"{username}|{expires_str}"
        if not hmac.compare_digest(_sign_value(payload), signature):
            return None
        if int(expires_str) < int(time.time()):
            return None
        return username
    except Exception:
        return None


def get_current_admin(request: Request) -> str:
    username = parse_session_cookie(request.cookies.get(SESSION_COOKIE_NAME))
    if not username:
        raise HTTPException(status_code=401, detail="Требуется авторизация")
    return username


@app.on_event("startup")
def startup() -> None:
    init_db()


@app.get("/")
def root() -> FileResponse:
    return FileResponse(static_dir / "site" / "index.html")


@app.get("/site")
def public_site() -> FileResponse:
    return FileResponse(static_dir / "site" / "index.html")


@app.get("/kiosk")
def kiosk_page() -> FileResponse:
    return FileResponse(static_dir / "kiosk" / "index.html")


@app.get("/stand")
def stand_page() -> FileResponse:
    return FileResponse(static_dir / "kiosk" / "index.html")


@app.get("/admin/login")
def admin_login_page(request: Request) -> FileResponse:
    if parse_session_cookie(request.cookies.get(SESSION_COOKIE_NAME)):
        return RedirectResponse(url="/admin", status_code=303)
    return FileResponse(static_dir / "admin" / "login.html")


@app.post("/admin/login")
def admin_login(
    username: str = Form(...),
    password: str = Form(...),
):
    if not (
        hmac.compare_digest(username, ADMIN_USERNAME)
        and hmac.compare_digest(password, ADMIN_PASSWORD)
    ):
        return RedirectResponse(
            url="/admin/login?error=" + quote("Неверный логин или пароль"),
            status_code=303,
        )

    response = RedirectResponse(url="/admin", status_code=303)
    response.set_cookie(
        key=SESSION_COOKIE_NAME,
        value=create_session_cookie(username),
        max_age=SESSION_TTL_SECONDS,
        httponly=True,
        samesite="lax",
        secure=False,
        path="/",
    )
    return response


@app.post("/admin/logout")
def admin_logout():
    response = RedirectResponse(url="/admin/login", status_code=303)
    response.delete_cookie(SESSION_COOKIE_NAME, path="/")
    return response


@app.get("/admin")
def admin_page(request: Request):
    if not parse_session_cookie(request.cookies.get(SESSION_COOKIE_NAME)):
        return RedirectResponse(url="/admin/login", status_code=303)
    return FileResponse(static_dir / "admin" / "index.html")


@app.get("/api/version")
def api_version():
    return get_current_version_info()


@app.get("/api/schedule")
def api_schedule():
    return load_schedule()


@app.get("/api/history")
def api_history(limit: int = 50, _: str = Depends(get_current_admin)):
    return history(limit)


@app.post("/api/upload")
async def api_upload(file: UploadFile = File(...), _: str = Depends(get_current_admin)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="Файл не передан")
    if not file.filename.lower().endswith(".xlsx"):
        raise HTTPException(status_code=400, detail="Поддерживаются только .xlsx файлы")

    TEMP_XLSX.parent.mkdir(parents=True, exist_ok=True)
    with TEMP_XLSX.open("wb") as f:
        shutil.copyfileobj(file.file, f)

    try:
        result = publish_schedule(TEMP_XLSX, original_filename=file.filename)
        return {
            "ok": True,
            "message": "Файл загружен и опубликован",
            "version": result["version"],
            "preview_count": len(result["schedule"]["items"]),
            "parser_info": result.get("parser_info", {}),
            "validation": result.get("validation", {}),
            "diagnostics": result.get("diagnostics", {}),
        }
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.post("/api/rollback/{version}")
def api_rollback(version: int, _: str = Depends(get_current_admin)):
    try:
        result = rollback_to_version(version)
        return {"ok": True, "message": f"Выполнен откат на базу версии {version}", "version": result["version"]}
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@app.get("/api/admin/me")
def api_admin_me(request: Request):
    username = parse_session_cookie(request.cookies.get(SESSION_COOKIE_NAME))
    if not username:
        raise HTTPException(status_code=401, detail="Требуется авторизация")
    return {"username": username}


@app.exception_handler(401)
async def unauthorized_handler(request: Request, exc: HTTPException):
    if request.url.path.startswith("/api/"):
        return JSONResponse(status_code=401, content={"detail": exc.detail})
    return RedirectResponse(url="/admin/login", status_code=303)
