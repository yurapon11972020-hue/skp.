from __future__ import annotations

import sqlite3
from contextlib import contextmanager
from .config import DB_PATH


def init_db() -> None:
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS uploads (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                filename TEXT NOT NULL,
                archived_path TEXT NOT NULL,
                status TEXT NOT NULL,
                version INTEGER NOT NULL,
                message TEXT,
                items_count INTEGER NOT NULL DEFAULT 0,
                groups_count INTEGER NOT NULL DEFAULT 0,
                days_count INTEGER NOT NULL DEFAULT 0
            )
            """
        )
        conn.commit()


@contextmanager
def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()
